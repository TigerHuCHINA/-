from socket import *

def main():
    tcp_client_socket = socket(AF_INET,SOCK_STREAM)

    tcp_client_socket.connect(("192.168.44.88",8080))
    while True:
        """无限循环可以实现无限聊天"""
        meg = input("请输入要发送的消息：")
        tcp_client_socket.send(meg.encode()) 

        recv_data = tcp_client_socket.recv(1024)  

        if recv_data:
            print("返回的消息为:",recv_data.decode('gbk'))
        else:
            print("对方已离线。。")
            break

    tcp_client_socket.close()


if __name__ == '__main__':
    main()
